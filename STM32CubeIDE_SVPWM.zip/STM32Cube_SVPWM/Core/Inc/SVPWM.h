
#include "stdio.h"
#include "math.h"

#define PI                3.14159265359f
#define degToRad          0.01745329251f
#define radToDeg          57.2957795131f
#define PIdivided_by3     1.04719755120f
#define _2divided_by3     0.66666666666f
#define _1divided_by3     0.33333333333f
#define root3_divided_by2 0.86602540378f
#define root3_divided_by3 0.57735026919f
#define root3             1.73205080757f
#define firstRatio        1.154f
#define thirdRatio        0.154f

float Vs; // source voltage
float Va; // a, b, c phase voltage
float Vb;
float Vc;
float Vx; // x, y reference axis voltage
float Vy;
float Vt; // third hamornic voltage
float thirdTheta; // angle of third hamornic wave
float pwmRes;     // pwm resolution
float m;          // slope of linear equation
float c;          // y axis intercept point
float pwm[3]={0}; // pwm output for a, b, c phase
	
void setVoltageSource(float vect)
{
  Vs = vect;
}

void setPWMResolution(float pwm)
{
  pwmRes = pwm;
  m = -2 * Vs / pwmRes;
  c = Vs;
}

float getPwm(int i)
{
  return pwm[i];
}

float getVx()
{
  return Vx;
}

float getVy()
{
  return Vy;
}

float getVa()
{
  return Va;
}

float getVb()
{
  return Vb;
}

float getVc()
{
  return Vc;
}

float constrain(float valIn, float valMin, float valMax)
{
	float valOut;
		 if(valIn > valMax)	valOut = valMax;
	else if(valIn < valMin)	valOut = valMin;
	else valOut = valIn;
	return valOut;
}

void updateClarke(float Vx, float Vy, float theta)
{
  float Vr = sqrt(Vx * Vx + Vy * Vy);
  Vr = constrain(Vr, 0, Vs);

  Va = _2divided_by3 * Vx;
  Vb = (Vy - root3_divided_by3 * Vx) / root3;
  Vc = 2.0f * (Va - Vx) - Vb;

  thirdTheta = theta * 3.0f;
  Vt = Vr * thirdRatio * cos(thirdTheta + PI);
  Va = Va * firstRatio + Vt;
  Vb = Vb * firstRatio + Vt;
  Vc = Vc * firstRatio + Vt;

  pwm[0] = (Va - c) / m;
  pwm[1] = (Vb - c) / m;
  pwm[2] = (Vc - c) / m;
}

void updatePark(float Vd, float Vq, float theta)
{
  float C = cos(theta);
  float S = sin(theta);
  float Vx = Vd * C - Vq * S;
  float Vy = Vd * S + Vq * C;
  float Vr = sqrt(Vx * Vx + Vy * Vy);
  Vr = constrain(Vr, 0, Vs);

  Va = _2divided_by3 * Vx;
  Vb = (Vy - root3_divided_by3 * Vx) / root3;
  Vc = 2.0f * (Va - Vx) - Vb;

  thirdTheta = theta * 3.0f;
  Vt = Vr * thirdRatio * cos(thirdTheta + PI);
  Va = Va * firstRatio + Vt;
  Vb = Vb * firstRatio + Vt;
  Vc = Vc * firstRatio + Vt;

  pwm[0] = (Va - c) / m;
  pwm[1] = (Vb - c) / m;
  pwm[2] = (Vc - c) / m;
}

void updateVector(float Vr, float theta)
{
  Vr = constrain(Vr, 0, Vs);

  Vx = Vr * cos(theta);
  Vy = Vr * sin(theta);
  Va = _2divided_by3 * Vx;
  Vb = (Vy - root3_divided_by3 * Vx) / root3;
  Vc = 2.0f * (Va - Vx) - Vb;

  thirdTheta = theta * 3.0f;
  Vt = Vr * thirdRatio * cos(thirdTheta + PI);
  Va = Va * firstRatio + Vt;
  Vb = Vb * firstRatio + Vt;
  Vc = Vc * firstRatio + Vt;

  pwm[0] = (Va - c) / m;
  pwm[1] = (Vb - c) / m;
  pwm[2] = (Vc - c) / m;
}

void updateClarkeDeg(float Vx, float Vy, float theta)
{
  theta *= degToRad;
  updateClarkeDeg(Vx, Vy, theta);
}

void updateParkDeg(float Vd, float Vq, float theta)
{
  theta *= degToRad;
  updatePark(Vd, Vq, theta);
}

void updateVectorDeg(float Vr, float theta)
{
  theta *= degToRad;
  updateVector(Vr, theta);
}


